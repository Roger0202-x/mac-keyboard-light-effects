---
name: mac-keyboard-light-effects
description: Build, install, update, validate, and share a standalone Apple Silicon MacBook menu-bar app that directly controls the built-in keyboard backlight without the macOS brightness HUD. Supports a full-range 0%-100% breathing effect and a double-flash response to visible notification banners. Use when a user asks for Mac keyboard breathing lights, notification flashing, silent keyboard-backlight control, modifying the light pattern, installing the utility on another M-series MacBook, or packaging this utility for another Codex user.
---

# Mac Keyboard Light Effects

Build the bundled source locally. Do not download a prebuilt binary or simulate keyboard-brightness keys.

## Workflow

1. Read `references/compatibility.md` before changing or installing the app.
2. Run `scripts/check_compatibility.sh`. Stop if it reports an unsupported Mac.
3. Quit an existing copy cleanly before updating it so the original keyboard state is restored.
4. Run `scripts/install_app.sh`. It installs to `~/Applications` by default; pass another destination directory only when the user requests it.
5. Run `scripts/verify_install.sh` against the installed app. If hardware access is sandbox-blocked, rerun the verification with the required local escalation.
6. Open the installed app and confirm that the menu contains `呼吸燈`, `通知閃燈`, and `測試通知閃燈`.
7. Use `測試通知閃燈` to verify two distinct flashes without requesting notification-monitoring permission.

The app runs independently after Codex closes.

## Install Commands

Treat the directory containing this `SKILL.md` as `skill_dir`.

```bash
"$skill_dir/scripts/check_compatibility.sh"
"$skill_dir/scripts/install_app.sh"
"$skill_dir/scripts/verify_install.sh"
open "$HOME/Applications/鍵盤燈光效果.app"
```

Writing to `~/Applications`, opening a GUI app, and reading the hardware backlight may require an approved command outside the Codex sandbox. Request the narrow permission needed for the exact command.

## Permission Model

- Direct breathing-light control needs no Accessibility, Input Monitoring, microphone, network, or Full Disk Access permission.
- Enabling `通知閃燈` asks for Accessibility permission because it observes only new windows from macOS Notification Center.
- Never bypass TCC, edit its database, or grant permissions programmatically. Let the user approve the macOS prompt.
- Never read notification databases or notification text.
- Do not add key logging or Input Monitoring.

## Modify Effects

Edit `assets/KeyboardLightApp.m`, then rerun the installer and verifier.

- Breathing range: `minimumBrightness` and `maximumBrightness`.
- Breathing speed choices: the `speeds` array.
- Notification timing: `notificationFlashDuration` and `notificationBrightnessAtElapsed:base:`.
- Preserve the saved brightness, auto-brightness, and idle-dimming restoration logic.
- Keep brightness values clamped to `0.0...1.0`.

## Bundled Files

- `assets/KeyboardLightApp.m`: menu-bar app source.
- `assets/KeyboardLightCLI.m`: direct-control diagnostic helper source.
- `assets/Info.plist`: portable app metadata.
- `scripts/check_compatibility.sh`: read-only hardware and toolchain checks.
- `scripts/install_app.sh`: deterministic local build, ad-hoc signing, and install.
- `scripts/verify_install.sh`: signature, bundle, and hardware verification.
- `references/compatibility.md`: support boundary and troubleshooting.
- `references/THIRD_PARTY_NOTICES.txt`: attribution retained in installed app resources.

## Share

Share the complete `mac-keyboard-light-effects` folder or its ZIP. The recipient places the folder in `~/.codex/skills/`, restarts Codex if needed, and invokes `$mac-keyboard-light-effects`.
