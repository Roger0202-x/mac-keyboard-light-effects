#import <Cocoa/Cocoa.h>
#import <dlfcn.h>
#import <math.h>
#import <objc/runtime.h>
#import <signal.h>
#import <unistd.h>

@interface KeyboardBrightnessClient : NSObject
- (NSArray<NSNumber *> *)copyKeyboardBacklightIDs;
- (float)brightnessForKeyboard:(uint64_t)keyboard;
- (void)setBrightness:(float)brightness
             fadeSpeed:(NSInteger)fadeSpeed
                commit:(BOOL)commit
           forKeyboard:(uint64_t)keyboard;
- (void)enableAutoBrightness:(BOOL)enabled forKeyboard:(uint64_t)keyboard;
- (BOOL)isAutoBrightnessEnabledForKeyboard:(uint64_t)keyboard;
- (void)suspendIdleDimming:(BOOL)suspend forKeyboard:(uint64_t)keyboard;
- (BOOL)isIdleDimmingSuspendedOnKeyboard:(uint64_t)keyboard;
@end

static volatile sig_atomic_t shouldStop = 0;
static uint64_t builtInKeyboard = 1;

static void handleSignal(int signalNumber) {
    (void)signalNumber;
    shouldStop = 1;
}

static KeyboardBrightnessClient *makeClient(void) {
    NSString *frameworkPath = @"/System/Library/PrivateFrameworks/CoreBrightness.framework";
    NSBundle *bundle = [NSBundle bundleWithPath:frameworkPath];
    NSError *loadError = nil;
    if (![bundle isLoaded] && ![bundle loadAndReturnError:&loadError]) {
        const char *binaryPath = "/System/Library/PrivateFrameworks/CoreBrightness.framework/CoreBrightness";
        if (dlopen(binaryPath, RTLD_LAZY | RTLD_LOCAL) == NULL) {
            fprintf(stderr, "Unable to load CoreBrightness: %s\n", loadError.localizedDescription.UTF8String);
            return nil;
        }
    }

    Class clientClass = NSClassFromString(@"KeyboardBrightnessClient");
    if (clientClass == Nil) {
        fprintf(stderr, "KeyboardBrightnessClient is unavailable on this Mac.\n");
        return nil;
    }

    KeyboardBrightnessClient *client = [[clientClass alloc] init];
    NSArray<NSNumber *> *keyboardIDs = [client copyKeyboardBacklightIDs];
    if (keyboardIDs.count > 0) {
        builtInKeyboard = keyboardIDs.firstObject.unsignedLongLongValue;
    }
    return client;
}

static void setBrightness(KeyboardBrightnessClient *client, float level, NSInteger fadeMs) {
    level = fmaxf(0.0f, fminf(1.0f, level));
    [client setBrightness:level fadeSpeed:fadeMs commit:YES forKeyboard:builtInKeyboard];
}

static void printUsage(void) {
    puts("KeyboardLightCLI\n"
         "\n"
         "Usage:\n"
         "  keyboard-light-cli get\n"
         "  keyboard-light-cli set <0.0-1.0> [fadeMs]\n"
         "  keyboard-light-cli breathe [cycles] [periodSeconds] [min] [max]\n"
         "  keyboard-light-cli ids\n"
         "  keyboard-light-cli methods\n"
         "\n"
         "Use 0 cycles for continuous breathing. Press Control-C to stop.");
}

static void printMethods(Class clientClass) {
    unsigned int methodCount = 0;
    Method *methods = class_copyMethodList(clientClass, &methodCount);
    for (unsigned int i = 0; i < methodCount; i++) {
        puts(sel_getName(method_getName(methods[i])));
    }
    free(methods);
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        if (argc < 2) {
            printUsage();
            return 0;
        }

        KeyboardBrightnessClient *client = makeClient();
        if (client == nil) {
            return 1;
        }

        NSString *command = [NSString stringWithUTF8String:argv[1]];
        if ([command isEqualToString:@"get"]) {
            printf("%.4f\n", [client brightnessForKeyboard:builtInKeyboard]);
            return 0;
        }

        if ([command isEqualToString:@"methods"]) {
            printMethods([client class]);
            return 0;
        }

        if ([command isEqualToString:@"ids"]) {
            NSLog(@"%@", [client copyKeyboardBacklightIDs]);
            return 0;
        }

        if ([command isEqualToString:@"set"]) {
            if (argc < 3) {
                printUsage();
                return 2;
            }
            float level = strtof(argv[2], NULL);
            NSInteger fadeMs = argc > 3 ? strtol(argv[3], NULL, 10) : 120;
            setBrightness(client, level, fadeMs);
            return 0;
        }

        if ([command isEqualToString:@"breathe"]) {
            NSInteger cycles = argc > 2 ? strtol(argv[2], NULL, 10) : 3;
            double period = argc > 3 ? strtod(argv[3], NULL) : 5.5;
            float minimum = argc > 4 ? strtof(argv[4], NULL) : 0.0f;
            float maximum = argc > 5 ? strtof(argv[5], NULL) : 1.0f;
            period = fmax(1.0, period);
            minimum = fmaxf(0.0f, fminf(1.0f, minimum));
            maximum = fmaxf(minimum, fminf(1.0f, maximum));

            signal(SIGINT, handleSignal);
            signal(SIGTERM, handleSignal);

            float original = [client brightnessForKeyboard:builtInKeyboard];
            BOOL originalAutoBrightness = [client isAutoBrightnessEnabledForKeyboard:builtInKeyboard];
            BOOL originalIdleSuspension = [client isIdleDimmingSuspendedOnKeyboard:builtInKeyboard];
            [client enableAutoBrightness:NO forKeyboard:builtInKeyboard];
            [client suspendIdleDimming:YES forKeyboard:builtInKeyboard];

            CFAbsoluteTime startedAt = CFAbsoluteTimeGetCurrent();
            while (!shouldStop) {
                double elapsed = CFAbsoluteTimeGetCurrent() - startedAt;
                if (cycles > 0 && elapsed >= period * cycles) {
                    break;
                }

                double phase = sin((2.0 * M_PI * elapsed / period) - (M_PI / 2.0));
                double eased = (phase + 1.0) * 0.5;
                float level = minimum + (float)eased * (maximum - minimum);
                setBrightness(client, level, 42);
                usleep(33333);
            }

            setBrightness(client, original, 220);
            [client suspendIdleDimming:originalIdleSuspension forKeyboard:builtInKeyboard];
            [client enableAutoBrightness:originalAutoBrightness forKeyboard:builtInKeyboard];
            return 0;
        }

        printUsage();
        return 2;
    }
}
