#import <ApplicationServices/ApplicationServices.h>
#import <AVFoundation/AVFoundation.h>
#import <Cocoa/Cocoa.h>
#import <dlfcn.h>
#import <math.h>

static inline float Clamp01(float value) {
    return fmaxf(0.0f, fminf(1.0f, value));
}

@interface KeyboardBrightnessClient : NSObject
- (NSArray<NSNumber *> *)copyKeyboardBacklightIDs;
- (float)brightnessForKeyboard:(uint64_t)keyboard;
- (void)setBrightness:(float)brightness
             fadeSpeed:(NSInteger)fadeSpeed
                commit:(BOOL)commit
           forKeyboard:(uint64_t)keyboard;
- (void)enableAutoBrightness:(BOOL)enabled forKeyboard:(uint64_t)keyboard;
- (BOOL)isAutoBrightnessEnabledForKeyboard:(uint64_t)keyboard;
- (void)suspendIdleDimming:(BOOL)suspend forKeyboard:(uint64_t)keyboard;
- (BOOL)isIdleDimmingSuspendedOnKeyboard:(uint64_t)keyboard;
@end

@class KeyboardBreathingAppDelegate;
static void notificationWindowCreatedCallback(AXObserverRef observer,
                                              AXUIElementRef element,
                                              CFStringRef notification,
                                              void *refcon);

@interface KeyboardBreathingAppDelegate : NSObject <NSApplicationDelegate>
@property(nonatomic, strong) KeyboardBrightnessClient *client;
@property(nonatomic) uint64_t keyboardID;
@property(nonatomic, strong) NSStatusItem *statusItem;
@property(nonatomic, strong) NSMenuItem *statusMenuItem;
@property(nonatomic, strong) NSMenuItem *breathingItem;
@property(nonatomic, strong) NSMenuItem *musicReactiveItem;
@property(nonatomic, strong) NSMenuItem *microphoneStatusItem;
@property(nonatomic, strong) NSMenuItem *notificationItem;
@property(nonatomic, strong) NSMenuItem *testNotificationItem;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, strong) AVAudioEngine *audioEngine;
@property(nonatomic, assign) AXObserverRef notificationObserver;
@property(nonatomic, assign) AXUIElementRef notificationCenterElement;
@property(nonatomic) BOOL breathing;
@property(nonatomic) BOOL musicReactiveEnabled;
@property(nonatomic) BOOL audioCaptureActive;
@property(nonatomic) BOOL notificationFlashEnabled;
@property(nonatomic) BOOL hasSavedState;
@property(nonatomic) BOOL originalAutoBrightness;
@property(nonatomic) BOOL originalIdleSuspension;
@property(nonatomic) float originalBrightness;
@property(nonatomic) float audioLevel;
@property(nonatomic) float audioTransient;
@property(nonatomic) float audioSensitivity;
@property(nonatomic) CFAbsoluteTime lastAudioInputAt;
@property(nonatomic) CFAbsoluteTime cycleStartedAt;
@property(nonatomic) CFAbsoluteTime notificationFlashStartedAt;
@property(nonatomic) CFAbsoluteTime lastNotificationDetectedAt;
@property(nonatomic) double periodSeconds;
@property(nonatomic) float minimumBrightness;
@property(nonatomic) float maximumBrightness;
- (void)triggerNotificationFlash;
@end

@implementation KeyboardBreathingAppDelegate

static const double notificationFlashDuration = 0.88;

- (BOOL)loadKeyboardClient {
    NSString *frameworkPath = @"/System/Library/PrivateFrameworks/CoreBrightness.framework";
    NSBundle *bundle = [NSBundle bundleWithPath:frameworkPath];
    NSError *loadError = nil;
    if (![bundle isLoaded] && ![bundle loadAndReturnError:&loadError]) {
        const char *binaryPath = "/System/Library/PrivateFrameworks/CoreBrightness.framework/CoreBrightness";
        if (dlopen(binaryPath, RTLD_LAZY | RTLD_LOCAL) == NULL) {
            return NO;
        }
    }

    Class clientClass = NSClassFromString(@"KeyboardBrightnessClient");
    if (clientClass == Nil) {
        return NO;
    }

    self.client = [[clientClass alloc] init];
    NSArray<NSNumber *> *keyboardIDs = [self.client copyKeyboardBacklightIDs];
    if (keyboardIDs.count == 0) {
        self.client = nil;
        return NO;
    }

    self.keyboardID = keyboardIDs.firstObject.unsignedLongLongValue;
    return YES;
}

- (NSImage *)statusImageNamed:(NSString *)symbolName {
    NSImage *image = [NSImage imageWithSystemSymbolName:symbolName
                              accessibilityDescription:@"鍵盤燈光效果"];
    image.template = YES;
    return image;
}

- (NSMenuItem *)menuItemWithTitle:(NSString *)title action:(SEL)action {
    NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:title action:action keyEquivalent:@""];
    item.target = self;
    return item;
}

- (void)buildStatusMenu {
    self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:NSSquareStatusItemLength];
    self.statusItem.button.image = [self statusImageNamed:@"keyboard"];
    self.statusItem.button.toolTip = @"鍵盤燈光效果";

    NSMenu *menu = [[NSMenu alloc] initWithTitle:@"鍵盤燈光效果"];
    self.statusMenuItem = [[NSMenuItem alloc] initWithTitle:@"燈光效果：準備中"
                                                    action:nil
                                             keyEquivalent:@""];
    self.statusMenuItem.enabled = NO;
    [menu addItem:self.statusMenuItem];
    [menu addItem:[NSMenuItem separatorItem]];

    self.breathingItem = [self menuItemWithTitle:@"呼吸燈" action:@selector(toggleBreathing:)];
    [menu addItem:self.breathingItem];

    NSMenuItem *speedItem = [[NSMenuItem alloc] initWithTitle:@"呼吸速度"
                                                       action:nil
                                                keyEquivalent:@""];
    NSMenu *speedMenu = [[NSMenu alloc] initWithTitle:@"呼吸速度"];
    NSArray<NSDictionary *> *speeds = @[
        @{@"title": @"自然（6 秒）", @"value": @6.0},
        @{@"title": @"緩慢（8 秒）", @"value": @8.0},
        @{@"title": @"輕快（4 秒）", @"value": @4.0}
    ];
    for (NSDictionary *speed in speeds) {
        NSMenuItem *item = [self menuItemWithTitle:speed[@"title"] action:@selector(selectSpeed:)];
        item.representedObject = speed[@"value"];
        item.state = [speed[@"value"] doubleValue] == self.periodSeconds
            ? NSControlStateValueOn
            : NSControlStateValueOff;
        [speedMenu addItem:item];
    }
    speedItem.submenu = speedMenu;
    [menu addItem:speedItem];

    [menu addItem:[NSMenuItem separatorItem]];
    self.musicReactiveItem = [self menuItemWithTitle:@"音樂律動鍵盤燈"
                                              action:@selector(toggleMusicReactive:)];
    [menu addItem:self.musicReactiveItem];

    NSMenuItem *sensitivityItem = [[NSMenuItem alloc] initWithTitle:@"音樂靈敏度"
                                                             action:nil
                                                      keyEquivalent:@""];
    NSMenu *sensitivityMenu = [[NSMenu alloc] initWithTitle:@"音樂靈敏度"];
    NSArray<NSDictionary *> *sensitivities = @[
        @{@"title": @"柔和", @"value": @0.90},
        @{@"title": @"自然", @"value": @1.25},
        @{@"title": @"強烈", @"value": @1.70}
    ];
    for (NSDictionary *sensitivity in sensitivities) {
        NSMenuItem *item = [self menuItemWithTitle:sensitivity[@"title"]
                                             action:@selector(selectSensitivity:)];
        item.representedObject = sensitivity[@"value"];
        item.state = fabs([sensitivity[@"value"] doubleValue] - self.audioSensitivity) < 0.01
            ? NSControlStateValueOn
            : NSControlStateValueOff;
        [sensitivityMenu addItem:item];
    }
    sensitivityItem.submenu = sensitivityMenu;
    [menu addItem:sensitivityItem];

    self.microphoneStatusItem = [[NSMenuItem alloc] initWithTitle:@"麥克風：檢查中"
                                                           action:nil
                                                    keyEquivalent:@""];
    self.microphoneStatusItem.enabled = NO;
    [menu addItem:self.microphoneStatusItem];

    [menu addItem:[NSMenuItem separatorItem]];
    self.notificationItem = [self menuItemWithTitle:@"通知閃燈"
                                              action:@selector(toggleNotificationFlash:)];
    [menu addItem:self.notificationItem];

    self.testNotificationItem = [self menuItemWithTitle:@"測試通知閃燈"
                                                  action:@selector(testNotificationFlash:)];
    [menu addItem:self.testNotificationItem];

    [menu addItem:[NSMenuItem separatorItem]];
    NSMenuItem *quitItem = [[NSMenuItem alloc] initWithTitle:@"結束鍵盤燈光效果"
                                                     action:@selector(quitApplication:)
                                              keyEquivalent:@"q"];
    quitItem.target = self;
    [menu addItem:quitItem];

    self.statusItem.menu = menu;
}

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    (void)notification;
    self.periodSeconds = 6.0;
    self.audioSensitivity = 1.25f;
    self.minimumBrightness = 0.0f;
    self.maximumBrightness = 1.0f;
    [self buildStatusMenu];
    [self updateMicrophoneStatus];

    BOOL keyboardAvailable = [self loadKeyboardClient];
    if (!keyboardAvailable) {
        self.breathingItem.enabled = NO;
        self.musicReactiveItem.enabled = NO;
        self.notificationItem.enabled = NO;
        self.testNotificationItem.enabled = NO;
        self.statusMenuItem.title = @"找不到鍵盤背光";
    }

    NSNotificationCenter *workspaceCenter = NSWorkspace.sharedWorkspace.notificationCenter;
    [workspaceCenter addObserver:self
                        selector:@selector(workspaceApplicationLaunched:)
                            name:NSWorkspaceDidLaunchApplicationNotification
                          object:nil];
    [workspaceCenter addObserver:self
                        selector:@selector(workspaceApplicationTerminated:)
                            name:NSWorkspaceDidTerminateApplicationNotification
                          object:nil];
    if (keyboardAvailable) {
        [self startBreathing];
    } else {
        [self updateMenuState];
    }
}

- (void)saveCurrentState {
    if (self.hasSavedState || self.client == nil) {
        return;
    }

    self.originalBrightness = [self.client brightnessForKeyboard:self.keyboardID];
    if (self.originalBrightness < 0.0f) {
        self.originalBrightness = 0.5f;
    }
    self.originalAutoBrightness = [self.client isAutoBrightnessEnabledForKeyboard:self.keyboardID];
    self.originalIdleSuspension = [self.client isIdleDimmingSuspendedOnKeyboard:self.keyboardID];
    self.hasSavedState = YES;
}

- (void)activateKeyboardControl {
    if (self.hasSavedState || self.client == nil) {
        return;
    }

    [self saveCurrentState];
    [self.client enableAutoBrightness:NO forKeyboard:self.keyboardID];
    [self.client suspendIdleDimming:YES forKeyboard:self.keyboardID];
}

- (void)restoreKeyboardState {
    if (!self.hasSavedState || self.client == nil) {
        return;
    }

    [self setKeyboardBrightness:self.originalBrightness fadeMs:220];
    [self.client suspendIdleDimming:self.originalIdleSuspension forKeyboard:self.keyboardID];
    [self.client enableAutoBrightness:self.originalAutoBrightness forKeyboard:self.keyboardID];
    self.hasSavedState = NO;
}

- (void)setKeyboardBrightness:(float)brightness fadeMs:(NSInteger)fadeMs {
    if (self.client == nil) {
        return;
    }
    [self.client setBrightness:Clamp01(brightness)
                     fadeSpeed:fadeMs
                        commit:YES
                   forKeyboard:self.keyboardID];
}

- (void)ensureAnimationTimer {
    if (self.timer != nil) {
        return;
    }

    self.timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 30.0)
                                                  target:self
                                                selector:@selector(updateAnimation:)
                                                userInfo:nil
                                                 repeats:YES];
    self.timer.tolerance = 0.005;
}

- (void)stopAnimationTimer {
    [self.timer invalidate];
    self.timer = nil;
}

- (BOOL)notificationFlashIsActiveAt:(CFAbsoluteTime)now {
    return self.notificationFlashStartedAt > 0.0 &&
        now - self.notificationFlashStartedAt < notificationFlashDuration;
}

- (float)breathingBrightnessAt:(CFAbsoluteTime)now {
    double elapsed = now - self.cycleStartedAt;
    double phase = sin((2.0 * M_PI * elapsed / self.periodSeconds) - (M_PI / 2.0));
    double eased = (phase + 1.0) * 0.5;
    return self.minimumBrightness + (float)eased * (self.maximumBrightness - self.minimumBrightness);
}

- (float)musicBrightness {
    float shaped = powf(Clamp01(self.audioLevel), 0.58f);
    return Clamp01(0.015f + shaped * 0.90f + self.audioTransient * 0.28f);
}

- (float)notificationBrightnessAtElapsed:(double)elapsed base:(float)baseBrightness {
    if (elapsed < 0.22) {
        return (float)sin(M_PI * elapsed / 0.22);
    }
    if (elapsed < 0.28) {
        return 0.0f;
    }
    if (elapsed < 0.62) {
        return (float)sin(M_PI * (elapsed - 0.28) / 0.34);
    }

    double progress = fmin(1.0, fmax(0.0, (elapsed - 0.62) / 0.26));
    double eased = progress * progress * (3.0 - 2.0 * progress);
    return baseBrightness * (float)eased;
}

- (void)stopAudioCaptureIfIdle {
    if (self.musicReactiveEnabled || !self.audioCaptureActive) {
        return;
    }

    @try {
        [self.audioEngine.inputNode removeTapOnBus:0];
    } @catch (NSException *exception) {
        (void)exception;
    }
    [self.audioEngine stop];
    self.audioEngine = nil;
    self.audioCaptureActive = NO;
    self.audioLevel = 0.0f;
    self.audioTransient = 0.0f;
}

- (void)finishAnimationIfIdleAt:(CFAbsoluteTime)now {
    BOOL notificationActive = [self notificationFlashIsActiveAt:now];
    BOOL keyboardActive = self.breathing || self.musicReactiveEnabled || notificationActive;
    if (!keyboardActive) {
        self.notificationFlashStartedAt = 0.0;
        [self restoreKeyboardState];
    }

    [self stopAudioCaptureIfIdle];
    if (!keyboardActive) {
        [self stopAnimationTimer];
    }
}

- (void)updateAnimation:(NSTimer *)timer {
    (void)timer;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    BOOL notificationActive = [self notificationFlashIsActiveAt:now];

    if (!notificationActive) {
        self.notificationFlashStartedAt = 0.0;
    }
    if (self.audioCaptureActive && now - self.lastAudioInputAt > 0.18) {
        self.audioLevel *= 0.90f;
    }
    self.audioTransient *= 0.84f;

    BOOL keyboardAnimationActive = self.breathing || self.musicReactiveEnabled || notificationActive;
    if (keyboardAnimationActive && self.client != nil) {
        float baseBrightness = self.originalBrightness;
        if (self.musicReactiveEnabled) {
            baseBrightness = [self musicBrightness];
        } else if (self.breathing) {
            baseBrightness = [self breathingBrightnessAt:now];
        }

        float outputBrightness = baseBrightness;
        if (notificationActive) {
            double elapsed = now - self.notificationFlashStartedAt;
            outputBrightness = [self notificationBrightnessAtElapsed:elapsed base:baseBrightness];
        }
        [self setKeyboardBrightness:outputBrightness fadeMs:20];
    }

    [self finishAnimationIfIdleAt:now];
}

- (void)updateMicrophoneStatus {
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
    switch (status) {
        case AVAuthorizationStatusAuthorized:
            self.microphoneStatusItem.title = self.audioCaptureActive
                ? @"麥克風：正在分析音量"
                : @"麥克風：已允許";
            break;
        case AVAuthorizationStatusDenied:
            self.microphoneStatusItem.title = @"麥克風：未允許";
            break;
        case AVAuthorizationStatusRestricted:
            self.microphoneStatusItem.title = @"麥克風：受系統限制";
            break;
        case AVAuthorizationStatusNotDetermined:
        default:
            self.microphoneStatusItem.title = @"麥克風：尚未詢問";
            break;
    }
}

- (void)updateMenuState {
    self.breathingItem.state = self.breathing ? NSControlStateValueOn : NSControlStateValueOff;
    self.musicReactiveItem.state = self.musicReactiveEnabled
        ? NSControlStateValueOn
        : NSControlStateValueOff;
    self.notificationItem.state = self.notificationFlashEnabled
        ? NSControlStateValueOn
        : NSControlStateValueOff;

    NSMutableArray<NSString *> *activeEffects = [NSMutableArray array];
    if (self.breathing) {
        [activeEffects addObject:@"呼吸燈"];
    }
    if (self.musicReactiveEnabled) {
        [activeEffects addObject:@"音樂律動"];
    }
    if (self.notificationFlashEnabled) {
        [activeEffects addObject:@"通知閃燈"];
    }

    if (activeEffects.count == 0) {
        self.statusMenuItem.title = @"燈光效果：已停止";
        self.statusItem.button.image = [self statusImageNamed:@"keyboard"];
    } else {
        self.statusMenuItem.title = [NSString stringWithFormat:@"已啟用：%@",
                                    [activeEffects componentsJoinedByString:@"、"]];
        NSString *symbol = self.musicReactiveEnabled
            ? @"waveform"
            : @"keyboard.fill";
        self.statusItem.button.image = [self statusImageNamed:symbol];
    }
    [self updateMicrophoneStatus];
}

- (void)acceptAudioLevel:(float)rawLevel peak:(float)rawPeak {
    float adjusted = Clamp01(rawLevel * self.audioSensitivity);
    float previous = self.audioLevel;
    float smoothing = adjusted > previous ? 0.52f : 0.13f;
    self.audioLevel = previous + (adjusted - previous) * smoothing;
    float rise = fmaxf(0.0f, adjusted - previous);
    float transient = Clamp01(rise * 3.2f + rawPeak * 0.16f);
    self.audioTransient = fmaxf(self.audioTransient * 0.78f, transient);
    self.lastAudioInputAt = CFAbsoluteTimeGetCurrent();
}

- (BOOL)startAudioCapture:(NSError **)outError {
    if (self.audioCaptureActive) {
        return YES;
    }

    AVAudioEngine *engine = [[AVAudioEngine alloc] init];
    AVAudioInputNode *inputNode = engine.inputNode;
    AVAudioFormat *format = [inputNode outputFormatForBus:0];
    if (format.channelCount == 0 || format.sampleRate <= 0.0) {
        if (outError != NULL) {
            *outError = [NSError errorWithDomain:@"KeyboardLightEffects"
                                            code:1
                                        userInfo:@{NSLocalizedDescriptionKey: @"找不到可用的麥克風輸入"}];
        }
        return NO;
    }

    __weak typeof(self) weakSelf = self;
    [inputNode installTapOnBus:0
                    bufferSize:1024
                        format:format
                         block:^(AVAudioPCMBuffer *buffer, AVAudioTime *when) {
        (void)when;
        float *const *channelData = buffer.floatChannelData;
        AVAudioFrameCount frameCount = buffer.frameLength;
        AVAudioChannelCount channelCount = buffer.format.channelCount;
        if (channelData == NULL || frameCount == 0 || channelCount == 0) {
            return;
        }

        AVAudioChannelCount channelsToRead = MIN(channelCount, 2);
        double sumSquares = 0.0;
        float peak = 0.0f;
        for (AVAudioChannelCount channel = 0; channel < channelsToRead; channel++) {
            float *samples = channelData[channel];
            for (AVAudioFrameCount frame = 0; frame < frameCount; frame++) {
                float sample = samples[frame];
                sumSquares += sample * sample;
                peak = fmaxf(peak, fabsf(sample));
            }
        }

        double sampleCount = (double)frameCount * channelsToRead;
        float rms = (float)sqrt(sumSquares / fmax(1.0, sampleCount));
        float decibels = 20.0f * log10f(fmaxf(rms, 0.000001f));
        float peakDecibels = 20.0f * log10f(fmaxf(peak, 0.000001f));
        float normalized = Clamp01((decibels + 58.0f) / 46.0f);
        float normalizedPeak = Clamp01((peakDecibels + 52.0f) / 46.0f);
        normalized = powf(normalized, 0.72f);

        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf acceptAudioLevel:normalized peak:normalizedPeak];
        });
    }];

    [engine prepare];
    NSError *startError = nil;
    if (![engine startAndReturnError:&startError]) {
        [inputNode removeTapOnBus:0];
        if (outError != NULL) {
            *outError = startError;
        }
        return NO;
    }

    self.audioEngine = engine;
    self.audioCaptureActive = YES;
    self.lastAudioInputAt = CFAbsoluteTimeGetCurrent();
    [self updateMicrophoneStatus];
    return YES;
}

- (void)showMicrophoneDeniedAlert {
    NSAlert *alert = [[NSAlert alloc] init];
    alert.messageText = @"需要麥克風權限";
    alert.informativeText = @"音樂律動只分析即時音量，不會錄音或儲存聲音。請在系統設定允許「鍵盤呼吸燈」使用麥克風。";
    [alert addButtonWithTitle:@"開啟系統設定"];
    [alert addButtonWithTitle:@"取消"];
    if ([alert runModal] == NSAlertFirstButtonReturn) {
        NSURL *url = [NSURL URLWithString:@"x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone"];
        [NSWorkspace.sharedWorkspace openURL:url];
    }
}

- (void)ensureAudioCaptureWithCompletion:(void (^)(BOOL ready))completion {
    if (self.audioCaptureActive) {
        completion(YES);
        return;
    }

    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];
    if (status == AVAuthorizationStatusAuthorized) {
        NSError *error = nil;
        BOOL started = [self startAudioCapture:&error];
        if (!started) {
            NSAlert *alert = [[NSAlert alloc] init];
            alert.messageText = @"無法啟動麥克風";
            alert.informativeText = error.localizedDescription ?: @"請確認麥克風目前可以使用。";
            [alert runModal];
        }
        completion(started);
        return;
    }

    if (status == AVAuthorizationStatusNotDetermined) {
        [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio
                                completionHandler:^(BOOL granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [self updateMicrophoneStatus];
                if (!granted) {
                    completion(NO);
                    return;
                }
                NSError *error = nil;
                BOOL started = [self startAudioCapture:&error];
                if (!started) {
                    NSAlert *alert = [[NSAlert alloc] init];
                    alert.messageText = @"無法啟動麥克風";
                    alert.informativeText = error.localizedDescription ?: @"請確認麥克風目前可以使用。";
                    [alert runModal];
                }
                completion(started);
            });
        }];
        return;
    }

    [self updateMicrophoneStatus];
    [self showMicrophoneDeniedAlert];
    completion(NO);
}

- (void)startBreathing {
    if (self.breathing || self.client == nil) {
        return;
    }

    self.musicReactiveEnabled = NO;
    [self stopAudioCaptureIfIdle];
    [self activateKeyboardControl];
    self.cycleStartedAt = CFAbsoluteTimeGetCurrent();
    self.breathing = YES;
    [self ensureAnimationTimer];
    [self updateMenuState];
}

- (void)stopBreathing {
    if (!self.breathing) {
        return;
    }

    self.breathing = NO;
    [self updateMenuState];
    [self finishAnimationIfIdleAt:CFAbsoluteTimeGetCurrent()];
}

- (void)triggerNotificationFlash {
    if (self.client == nil) {
        return;
    }
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - self.lastNotificationDetectedAt < 0.8) {
        return;
    }

    self.lastNotificationDetectedAt = now;
    [self activateKeyboardControl];
    self.notificationFlashStartedAt = now;
    [self ensureAnimationTimer];
}

- (BOOL)requestAccessibilityPermission {
    NSString *promptKey = (__bridge NSString *)kAXTrustedCheckOptionPrompt;
    NSDictionary *options = @{promptKey: @YES};
    BOOL trusted = AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)options);
    if (!trusted) {
        self.statusMenuItem.title = @"通知閃燈：請先允許輔助使用";
    }
    return trusted;
}

- (BOOL)setupNotificationObserver {
    if (self.notificationObserver != NULL) {
        return YES;
    }

    NSArray<NSRunningApplication *> *centers =
        [NSRunningApplication runningApplicationsWithBundleIdentifier:@"com.apple.notificationcenterui"];
    NSRunningApplication *center = centers.firstObject;
    if (center == nil) {
        return NO;
    }

    AXObserverRef observer = NULL;
    AXError createError = AXObserverCreate(center.processIdentifier,
                                           notificationWindowCreatedCallback,
                                           &observer);
    if (createError != kAXErrorSuccess || observer == NULL) {
        return NO;
    }

    AXUIElementRef appElement = AXUIElementCreateApplication(center.processIdentifier);
    AXError addError = AXObserverAddNotification(observer,
                                                 appElement,
                                                 kAXWindowCreatedNotification,
                                                 (__bridge void *)self);
    if (addError != kAXErrorSuccess) {
        CFRelease(appElement);
        CFRelease(observer);
        return NO;
    }

    self.notificationObserver = observer;
    self.notificationCenterElement = appElement;
    CFRunLoopAddSource(CFRunLoopGetMain(),
                       AXObserverGetRunLoopSource(observer),
                       kCFRunLoopCommonModes);
    return YES;
}

- (void)cleanupNotificationObserver {
    if (self.notificationObserver == NULL) {
        return;
    }

    AXObserverRemoveNotification(self.notificationObserver,
                                 self.notificationCenterElement,
                                 kAXWindowCreatedNotification);
    CFRunLoopRemoveSource(CFRunLoopGetMain(),
                          AXObserverGetRunLoopSource(self.notificationObserver),
                          kCFRunLoopCommonModes);
    CFRelease(self.notificationCenterElement);
    CFRelease(self.notificationObserver);
    self.notificationCenterElement = NULL;
    self.notificationObserver = NULL;
}

- (void)toggleBreathing:(id)sender {
    (void)sender;
    self.breathing ? [self stopBreathing] : [self startBreathing];
}

- (void)toggleMusicReactive:(id)sender {
    (void)sender;
    if (self.musicReactiveEnabled) {
        self.musicReactiveEnabled = NO;
        [self updateMenuState];
        [self stopAudioCaptureIfIdle];
        [self finishAnimationIfIdleAt:CFAbsoluteTimeGetCurrent()];
        return;
    }

    [self ensureAudioCaptureWithCompletion:^(BOOL ready) {
        if (!ready || self.client == nil) {
            return;
        }
        self.breathing = NO;
        self.musicReactiveEnabled = YES;
        [self activateKeyboardControl];
        [self ensureAnimationTimer];
        [self updateMenuState];
    }];
}

- (void)toggleNotificationFlash:(id)sender {
    (void)sender;
    if (self.notificationFlashEnabled) {
        self.notificationFlashEnabled = NO;
        self.notificationFlashStartedAt = 0.0;
        [self cleanupNotificationObserver];
        [self finishAnimationIfIdleAt:CFAbsoluteTimeGetCurrent()];
        [self updateMenuState];
        return;
    }

    if (![self requestAccessibilityPermission]) {
        return;
    }
    if (![self setupNotificationObserver]) {
        self.statusMenuItem.title = @"通知閃燈：無法連接通知中心";
        return;
    }
    self.notificationFlashEnabled = YES;
    [self updateMenuState];
}

- (void)testNotificationFlash:(id)sender {
    (void)sender;
    self.lastNotificationDetectedAt = 0.0;
    [self triggerNotificationFlash];
}

- (void)selectSpeed:(NSMenuItem *)sender {
    self.periodSeconds = [sender.representedObject doubleValue];
    for (NSMenuItem *item in sender.menu.itemArray) {
        item.state = item == sender ? NSControlStateValueOn : NSControlStateValueOff;
    }
    self.cycleStartedAt = CFAbsoluteTimeGetCurrent();
}

- (void)selectSensitivity:(NSMenuItem *)sender {
    self.audioSensitivity = [sender.representedObject floatValue];
    for (NSMenuItem *item in sender.menu.itemArray) {
        item.state = item == sender ? NSControlStateValueOn : NSControlStateValueOff;
    }
}

- (void)workspaceApplicationLaunched:(NSNotification *)notification {
    NSRunningApplication *application = notification.userInfo[NSWorkspaceApplicationKey];
    if (self.notificationFlashEnabled &&
        [application.bundleIdentifier isEqualToString:@"com.apple.notificationcenterui"]) {
        [self cleanupNotificationObserver];
        [self setupNotificationObserver];
    }
}

- (void)workspaceApplicationTerminated:(NSNotification *)notification {
    NSRunningApplication *application = notification.userInfo[NSWorkspaceApplicationKey];
    if ([application.bundleIdentifier isEqualToString:@"com.apple.notificationcenterui"]) {
        [self cleanupNotificationObserver];
    }
}

- (void)quitApplication:(id)sender {
    (void)sender;
    [NSApp terminate:nil];
}

- (void)applicationWillTerminate:(NSNotification *)notification {
    (void)notification;
    self.breathing = NO;
    self.musicReactiveEnabled = NO;
    self.notificationFlashEnabled = NO;
    self.notificationFlashStartedAt = 0.0;
    [self cleanupNotificationObserver];
    [self stopAudioCaptureIfIdle];
    [self stopAnimationTimer];
    [self restoreKeyboardState];
    [NSWorkspace.sharedWorkspace.notificationCenter removeObserver:self];
}

@end

static void notificationWindowCreatedCallback(AXObserverRef observer,
                                              AXUIElementRef element,
                                              CFStringRef notification,
                                              void *refcon) {
    (void)observer;
    (void)element;
    if (!CFEqual(notification, kAXWindowCreatedNotification) || refcon == NULL) {
        return;
    }

    KeyboardBreathingAppDelegate *delegate = (__bridge KeyboardBreathingAppDelegate *)refcon;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (delegate.notificationFlashEnabled) {
            [delegate triggerNotificationFlash];
        }
    });
}

int main(int argc, const char *argv[]) {
    (void)argc;
    (void)argv;
    @autoreleasepool {
        NSApplication *application = [NSApplication sharedApplication];
        KeyboardBreathingAppDelegate *delegate = [[KeyboardBreathingAppDelegate alloc] init];
        application.delegate = delegate;
        [application run];
    }
    return 0;
}
