#import <ApplicationServices/ApplicationServices.h>
#import <Cocoa/Cocoa.h>
#import <dlfcn.h>
#import <math.h>

@interface KeyboardBrightnessClient : NSObject
- (NSArray<NSNumber *> *)copyKeyboardBacklightIDs;
- (float)brightnessForKeyboard:(uint64_t)keyboard;
- (void)setBrightness:(float)brightness
             fadeSpeed:(NSInteger)fadeSpeed
                commit:(BOOL)commit
           forKeyboard:(uint64_t)keyboard;
- (void)enableAutoBrightness:(BOOL)enabled forKeyboard:(uint64_t)keyboard;
- (BOOL)isAutoBrightnessEnabledForKeyboard:(uint64_t)keyboard;
- (void)suspendIdleDimming:(BOOL)suspend forKeyboard:(uint64_t)keyboard;
- (BOOL)isIdleDimmingSuspendedOnKeyboard:(uint64_t)keyboard;
@end

@class KeyboardBreathingAppDelegate;
static void notificationWindowCreatedCallback(AXObserverRef observer,
                                              AXUIElementRef element,
                                              CFStringRef notification,
                                              void *refcon);

@interface KeyboardBreathingAppDelegate : NSObject <NSApplicationDelegate>
@property(nonatomic, strong) KeyboardBrightnessClient *client;
@property(nonatomic) uint64_t keyboardID;
@property(nonatomic, strong) NSStatusItem *statusItem;
@property(nonatomic, strong) NSMenuItem *statusMenuItem;
@property(nonatomic, strong) NSMenuItem *breathingItem;
@property(nonatomic, strong) NSMenuItem *notificationItem;
@property(nonatomic, strong) NSMenuItem *testNotificationItem;
@property(nonatomic, strong) NSTimer *timer;
@property(nonatomic, assign) AXObserverRef notificationObserver;
@property(nonatomic, assign) AXUIElementRef notificationCenterElement;
@property(nonatomic) BOOL breathing;
@property(nonatomic) BOOL notificationFlashEnabled;
@property(nonatomic) BOOL hasSavedState;
@property(nonatomic) BOOL originalAutoBrightness;
@property(nonatomic) BOOL originalIdleSuspension;
@property(nonatomic) float originalBrightness;
@property(nonatomic) CFAbsoluteTime cycleStartedAt;
@property(nonatomic) CFAbsoluteTime notificationFlashStartedAt;
@property(nonatomic) CFAbsoluteTime lastNotificationDetectedAt;
@property(nonatomic) double periodSeconds;
@property(nonatomic) float minimumBrightness;
@property(nonatomic) float maximumBrightness;
- (void)triggerNotificationFlash;
@end

@implementation KeyboardBreathingAppDelegate

static const double notificationFlashDuration = 0.88;

- (BOOL)loadKeyboardClient {
    NSString *frameworkPath = @"/System/Library/PrivateFrameworks/CoreBrightness.framework";
    NSBundle *bundle = [NSBundle bundleWithPath:frameworkPath];
    NSError *loadError = nil;
    if (![bundle isLoaded] && ![bundle loadAndReturnError:&loadError]) {
        const char *binaryPath = "/System/Library/PrivateFrameworks/CoreBrightness.framework/CoreBrightness";
        if (dlopen(binaryPath, RTLD_LAZY | RTLD_LOCAL) == NULL) {
            return NO;
        }
    }

    Class clientClass = NSClassFromString(@"KeyboardBrightnessClient");
    if (clientClass == Nil) {
        return NO;
    }

    self.client = [[clientClass alloc] init];
    NSArray<NSNumber *> *keyboardIDs = [self.client copyKeyboardBacklightIDs];
    if (keyboardIDs.count == 0) {
        return NO;
    }

    self.keyboardID = keyboardIDs.firstObject.unsignedLongLongValue;
    return YES;
}

- (NSImage *)statusImageNamed:(NSString *)symbolName {
    NSImage *image = [NSImage imageWithSystemSymbolName:symbolName
                              accessibilityDescription:@"鍵盤燈光效果"];
    image.template = YES;
    return image;
}

- (NSMenuItem *)menuItemWithTitle:(NSString *)title action:(SEL)action {
    NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:title action:action keyEquivalent:@""];
    item.target = self;
    return item;
}

- (void)buildStatusMenu {
    self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:NSSquareStatusItemLength];
    self.statusItem.button.image = [self statusImageNamed:@"keyboard"];
    self.statusItem.button.toolTip = @"鍵盤燈光效果";

    NSMenu *menu = [[NSMenu alloc] initWithTitle:@"鍵盤燈光效果"];
    self.statusMenuItem = [[NSMenuItem alloc] initWithTitle:@"燈光效果：準備中"
                                                    action:nil
                                             keyEquivalent:@""];
    self.statusMenuItem.enabled = NO;
    [menu addItem:self.statusMenuItem];
    [menu addItem:[NSMenuItem separatorItem]];

    self.breathingItem = [self menuItemWithTitle:@"呼吸燈" action:@selector(toggleBreathing:)];
    [menu addItem:self.breathingItem];

    NSMenuItem *speedItem = [[NSMenuItem alloc] initWithTitle:@"呼吸速度"
                                                       action:nil
                                                keyEquivalent:@""];
    NSMenu *speedMenu = [[NSMenu alloc] initWithTitle:@"呼吸速度"];
    NSArray<NSDictionary *> *speeds = @[
        @{@"title": @"自然（6 秒）", @"value": @6.0},
        @{@"title": @"緩慢（8 秒）", @"value": @8.0},
        @{@"title": @"輕快（4 秒）", @"value": @4.0}
    ];
    for (NSDictionary *speed in speeds) {
        NSMenuItem *item = [self menuItemWithTitle:speed[@"title"] action:@selector(selectSpeed:)];
        item.representedObject = speed[@"value"];
        item.state = [speed[@"value"] doubleValue] == self.periodSeconds
            ? NSControlStateValueOn
            : NSControlStateValueOff;
        [speedMenu addItem:item];
    }
    speedItem.submenu = speedMenu;
    [menu addItem:speedItem];

    [menu addItem:[NSMenuItem separatorItem]];
    self.notificationItem = [self menuItemWithTitle:@"通知閃燈" action:@selector(toggleNotificationFlash:)];
    [menu addItem:self.notificationItem];

    self.testNotificationItem = [self menuItemWithTitle:@"測試通知閃燈" action:@selector(testNotificationFlash:)];
    [menu addItem:self.testNotificationItem];

    [menu addItem:[NSMenuItem separatorItem]];
    NSMenuItem *quitItem = [[NSMenuItem alloc] initWithTitle:@"結束鍵盤燈光效果"
                                                     action:@selector(quitApplication:)
                                              keyEquivalent:@"q"];
    quitItem.target = self;
    [menu addItem:quitItem];

    self.statusItem.menu = menu;
}

- (void)applicationDidFinishLaunching:(NSNotification *)notification {
    (void)notification;
    self.periodSeconds = 6.0;
    self.minimumBrightness = 0.0f;
    self.maximumBrightness = 1.0f;
    [self buildStatusMenu];

    if (![self loadKeyboardClient]) {
        self.statusMenuItem.title = @"找不到鍵盤背光";
        self.breathingItem.enabled = NO;
        self.notificationItem.enabled = NO;
        self.testNotificationItem.enabled = NO;
        NSAlert *alert = [[NSAlert alloc] init];
        alert.messageText = @"無法控制鍵盤背光";
        alert.informativeText = @"這台 Mac 目前沒有提供可用的內建鍵盤背光介面。";
        [alert runModal];
        return;
    }

    NSNotificationCenter *workspaceCenter = NSWorkspace.sharedWorkspace.notificationCenter;
    [workspaceCenter addObserver:self
                        selector:@selector(workspaceApplicationLaunched:)
                            name:NSWorkspaceDidLaunchApplicationNotification
                          object:nil];
    [workspaceCenter addObserver:self
                        selector:@selector(workspaceApplicationTerminated:)
                            name:NSWorkspaceDidTerminateApplicationNotification
                          object:nil];

    [self startBreathing];
}

- (void)saveCurrentState {
    if (self.hasSavedState) {
        return;
    }

    self.originalBrightness = [self.client brightnessForKeyboard:self.keyboardID];
    if (self.originalBrightness < 0.0f) {
        self.originalBrightness = 0.5f;
    }
    self.originalAutoBrightness = [self.client isAutoBrightnessEnabledForKeyboard:self.keyboardID];
    self.originalIdleSuspension = [self.client isIdleDimmingSuspendedOnKeyboard:self.keyboardID];
    self.hasSavedState = YES;
}

- (void)activateKeyboardControl {
    if (self.hasSavedState) {
        return;
    }

    [self saveCurrentState];
    [self.client enableAutoBrightness:NO forKeyboard:self.keyboardID];
    [self.client suspendIdleDimming:YES forKeyboard:self.keyboardID];
}

- (void)restoreKeyboardState {
    if (!self.hasSavedState) {
        return;
    }

    [self setKeyboardBrightness:self.originalBrightness fadeMs:220];
    [self.client suspendIdleDimming:self.originalIdleSuspension forKeyboard:self.keyboardID];
    [self.client enableAutoBrightness:self.originalAutoBrightness forKeyboard:self.keyboardID];
    self.hasSavedState = NO;
}

- (void)setKeyboardBrightness:(float)brightness fadeMs:(NSInteger)fadeMs {
    brightness = fmaxf(0.0f, fminf(1.0f, brightness));
    [self.client setBrightness:brightness
                     fadeSpeed:fadeMs
                        commit:YES
                   forKeyboard:self.keyboardID];
}

- (void)ensureAnimationTimer {
    if (self.timer != nil) {
        return;
    }

    self.timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 30.0)
                                                  target:self
                                                selector:@selector(updateAnimation:)
                                                userInfo:nil
                                                 repeats:YES];
    self.timer.tolerance = 0.005;
}

- (void)stopAnimationTimer {
    [self.timer invalidate];
    self.timer = nil;
}

- (BOOL)notificationFlashIsActiveAt:(CFAbsoluteTime)now {
    return self.notificationFlashStartedAt > 0.0 &&
        now - self.notificationFlashStartedAt < notificationFlashDuration;
}

- (float)breathingBrightnessAt:(CFAbsoluteTime)now {
    double elapsed = now - self.cycleStartedAt;
    double phase = sin((2.0 * M_PI * elapsed / self.periodSeconds) - (M_PI / 2.0));
    double eased = (phase + 1.0) * 0.5;
    return self.minimumBrightness + (float)eased * (self.maximumBrightness - self.minimumBrightness);
}

- (float)notificationBrightnessAtElapsed:(double)elapsed base:(float)baseBrightness {
    if (elapsed < 0.22) {
        return (float)sin(M_PI * elapsed / 0.22);
    }
    if (elapsed < 0.28) {
        return 0.0f;
    }
    if (elapsed < 0.62) {
        return (float)sin(M_PI * (elapsed - 0.28) / 0.34);
    }

    double progress = fmin(1.0, fmax(0.0, (elapsed - 0.62) / 0.26));
    double eased = progress * progress * (3.0 - 2.0 * progress);
    return baseBrightness * (float)eased;
}

- (void)finishAnimationIfIdleAt:(CFAbsoluteTime)now {
    if (self.breathing || [self notificationFlashIsActiveAt:now]) {
        return;
    }

    self.notificationFlashStartedAt = 0.0;
    [self stopAnimationTimer];
    [self restoreKeyboardState];
}

- (void)updateAnimation:(NSTimer *)timer {
    (void)timer;
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    BOOL notificationActive = [self notificationFlashIsActiveAt:now];

    if (!notificationActive) {
        self.notificationFlashStartedAt = 0.0;
    }

    float baseBrightness = self.breathing
        ? [self breathingBrightnessAt:now]
        : self.originalBrightness;
    float outputBrightness = baseBrightness;

    if (notificationActive) {
        double elapsed = now - self.notificationFlashStartedAt;
        outputBrightness = [self notificationBrightnessAtElapsed:elapsed base:baseBrightness];
    }

    [self setKeyboardBrightness:outputBrightness fadeMs:24];
    [self finishAnimationIfIdleAt:now];
}

- (void)updateMenuState {
    self.breathingItem.state = self.breathing ? NSControlStateValueOn : NSControlStateValueOff;
    self.notificationItem.state = self.notificationFlashEnabled ? NSControlStateValueOn : NSControlStateValueOff;

    NSMutableArray<NSString *> *activeEffects = [NSMutableArray array];
    if (self.breathing) {
        [activeEffects addObject:@"呼吸燈"];
    }
    if (self.notificationFlashEnabled) {
        [activeEffects addObject:@"通知閃燈"];
    }

    if (activeEffects.count == 0) {
        self.statusMenuItem.title = @"燈光效果：已停止";
        self.statusItem.button.image = [self statusImageNamed:@"keyboard"];
    } else {
        self.statusMenuItem.title = [NSString stringWithFormat:@"已啟用：%@",
                                    [activeEffects componentsJoinedByString:@"、"]];
        self.statusItem.button.image = [self statusImageNamed:@"keyboard.fill"];
    }
}

- (void)startBreathing {
    if (self.breathing || self.client == nil) {
        return;
    }

    [self activateKeyboardControl];
    self.cycleStartedAt = CFAbsoluteTimeGetCurrent();
    self.breathing = YES;
    [self ensureAnimationTimer];
    [self updateMenuState];
}

- (void)stopBreathing {
    if (!self.breathing) {
        return;
    }

    self.breathing = NO;
    [self updateMenuState];
    [self finishAnimationIfIdleAt:CFAbsoluteTimeGetCurrent()];
}

- (void)triggerNotificationFlash {
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (now - self.lastNotificationDetectedAt < 0.8) {
        return;
    }

    self.lastNotificationDetectedAt = now;
    [self activateKeyboardControl];
    self.notificationFlashStartedAt = now;
    [self ensureAnimationTimer];
}

- (BOOL)requestAccessibilityPermission {
    NSString *promptKey = (__bridge NSString *)kAXTrustedCheckOptionPrompt;
    NSDictionary *options = @{promptKey: @YES};
    BOOL trusted = AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)options);
    if (!trusted) {
        self.statusMenuItem.title = @"通知閃燈：請先允許輔助使用";
    }
    return trusted;
}

- (BOOL)setupNotificationObserver {
    if (self.notificationObserver != NULL) {
        return YES;
    }

    NSArray<NSRunningApplication *> *centers =
        [NSRunningApplication runningApplicationsWithBundleIdentifier:@"com.apple.notificationcenterui"];
    NSRunningApplication *center = centers.firstObject;
    if (center == nil) {
        return NO;
    }

    AXObserverRef observer = NULL;
    AXError createError = AXObserverCreate(center.processIdentifier,
                                           notificationWindowCreatedCallback,
                                           &observer);
    if (createError != kAXErrorSuccess || observer == NULL) {
        return NO;
    }

    AXUIElementRef appElement = AXUIElementCreateApplication(center.processIdentifier);
    AXError addError = AXObserverAddNotification(observer,
                                                 appElement,
                                                 kAXWindowCreatedNotification,
                                                 (__bridge void *)self);
    if (addError != kAXErrorSuccess) {
        CFRelease(appElement);
        CFRelease(observer);
        return NO;
    }

    self.notificationObserver = observer;
    self.notificationCenterElement = appElement;
    CFRunLoopAddSource(CFRunLoopGetMain(),
                       AXObserverGetRunLoopSource(observer),
                       kCFRunLoopCommonModes);
    return YES;
}

- (void)cleanupNotificationObserver {
    if (self.notificationObserver == NULL) {
        return;
    }

    AXObserverRemoveNotification(self.notificationObserver,
                                 self.notificationCenterElement,
                                 kAXWindowCreatedNotification);
    CFRunLoopRemoveSource(CFRunLoopGetMain(),
                          AXObserverGetRunLoopSource(self.notificationObserver),
                          kCFRunLoopCommonModes);
    CFRelease(self.notificationCenterElement);
    CFRelease(self.notificationObserver);
    self.notificationCenterElement = NULL;
    self.notificationObserver = NULL;
}

- (void)toggleBreathing:(id)sender {
    (void)sender;
    self.breathing ? [self stopBreathing] : [self startBreathing];
}

- (void)toggleNotificationFlash:(id)sender {
    (void)sender;
    if (self.notificationFlashEnabled) {
        self.notificationFlashEnabled = NO;
        self.notificationFlashStartedAt = 0.0;
        [self cleanupNotificationObserver];
        [self finishAnimationIfIdleAt:CFAbsoluteTimeGetCurrent()];
        [self updateMenuState];
        return;
    }

    if (![self requestAccessibilityPermission]) {
        return;
    }
    if (![self setupNotificationObserver]) {
        self.statusMenuItem.title = @"通知閃燈：無法連接通知中心";
        return;
    }
    self.notificationFlashEnabled = YES;
    [self updateMenuState];
}

- (void)testNotificationFlash:(id)sender {
    (void)sender;
    self.lastNotificationDetectedAt = 0.0;
    [self triggerNotificationFlash];
}

- (void)selectSpeed:(NSMenuItem *)sender {
    self.periodSeconds = [sender.representedObject doubleValue];
    for (NSMenuItem *item in sender.menu.itemArray) {
        item.state = item == sender ? NSControlStateValueOn : NSControlStateValueOff;
    }
    self.cycleStartedAt = CFAbsoluteTimeGetCurrent();
}

- (void)workspaceApplicationLaunched:(NSNotification *)notification {
    NSRunningApplication *application = notification.userInfo[NSWorkspaceApplicationKey];
    if (self.notificationFlashEnabled &&
        [application.bundleIdentifier isEqualToString:@"com.apple.notificationcenterui"]) {
        [self cleanupNotificationObserver];
        [self setupNotificationObserver];
    }
}

- (void)workspaceApplicationTerminated:(NSNotification *)notification {
    NSRunningApplication *application = notification.userInfo[NSWorkspaceApplicationKey];
    if ([application.bundleIdentifier isEqualToString:@"com.apple.notificationcenterui"]) {
        [self cleanupNotificationObserver];
    }
}

- (void)quitApplication:(id)sender {
    (void)sender;
    [NSApp terminate:nil];
}

- (void)applicationWillTerminate:(NSNotification *)notification {
    (void)notification;
    self.breathing = NO;
    self.notificationFlashEnabled = NO;
    self.notificationFlashStartedAt = 0.0;
    [self cleanupNotificationObserver];
    [self stopAnimationTimer];
    [self restoreKeyboardState];
    [NSWorkspace.sharedWorkspace.notificationCenter removeObserver:self];
}

@end

static void notificationWindowCreatedCallback(AXObserverRef observer,
                                              AXUIElementRef element,
                                              CFStringRef notification,
                                              void *refcon) {
    (void)observer;
    (void)element;
    if (!CFEqual(notification, kAXWindowCreatedNotification) || refcon == NULL) {
        return;
    }

    KeyboardBreathingAppDelegate *delegate = (__bridge KeyboardBreathingAppDelegate *)refcon;
    dispatch_async(dispatch_get_main_queue(), ^{
        if (delegate.notificationFlashEnabled) {
            [delegate triggerNotificationFlash];
        }
    });
}

int main(int argc, const char *argv[]) {
    (void)argc;
    (void)argv;
    @autoreleasepool {
        NSApplication *application = [NSApplication sharedApplication];
        KeyboardBreathingAppDelegate *delegate = [[KeyboardBreathingAppDelegate alloc] init];
        application.delegate = delegate;
        [application run];
    }
    return 0;
}
