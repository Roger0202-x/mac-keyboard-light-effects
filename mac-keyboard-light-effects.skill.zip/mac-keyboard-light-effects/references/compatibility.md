# Compatibility And Safety

## Supported

- Apple Silicon MacBook Air or MacBook Pro with a built-in backlit keyboard.
- macOS 14 or later.
- Apple Command Line Tools with `/usr/bin/clang`.
- A `Keyboard Backlight` device visible through `hidutil list`.

The original build was verified on an M3 MacBook Air running macOS 26.5.

## Hardware Boundary

The built-in keyboard exposes one global white-backlight channel. It cannot provide left-to-right, zone, per-key, or color effects. Do not promise those effects without different hardware.

The app dynamically loads the private `KeyboardBrightnessClient` class from CoreBrightness. A future macOS release may rename or remove this interface. Stop and report the compatibility failure if the class or keyboard ID is unavailable; do not disable SIP or install a driver.

## Privacy Boundary

- No network access.
- No notification database access.
- No notification text collection.
- No key monitoring or typing data.
- No Full Disk Access.
- Music response uses microphone permission only while the effect is enabled.
- Audio is reduced to live loudness values in memory. It is not recorded, stored, transcribed, or transmitted.
- Notification flash compares visible Notification Center window IDs, ownership, layer, alpha, and bounds. It does not read titles, pixels, or notification content and needs no Accessibility or Screen Recording permission.

Only visible notification banners trigger the automatic flash. Silent notifications or banners suppressed by Focus may not trigger it.

## Runtime Behavior

- The app saves keyboard brightness, automatic-brightness state, and idle-dimming state before controlling the light.
- Stopping all active animation or quitting restores those values.
- Breathing and music-reactive keyboard control are mutually exclusive. Notification flashes can temporarily override either mode.
- The app continues after Codex closes.
- The app does not launch automatically after login unless the user separately requests that behavior.

## Troubleshooting

- `brightness=-1`: rerun the diagnostic outside a restricted sandbox.
- No automatic notification flash: confirm the notification appears as a visible banner and is not suppressed by Focus, then toggle `通知閃燈` off and on once.
- No music response: enable Microphone for `鍵盤呼吸燈`, then toggle the effect again.
- No menu icon: confirm the process launches and that `LSUIElement` is true in `Info.plist`.
- Invalid signature: clear extended attributes on the installed app, ad-hoc sign it again, and rerun `codesign --verify`.
