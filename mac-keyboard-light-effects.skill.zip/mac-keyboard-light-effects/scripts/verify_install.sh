#!/bin/zsh
set -euo pipefail

app_path="${1:-${HOME}/Applications/鍵盤燈光效果.app}"
app_executable="${app_path}/Contents/MacOS/KeyboardLightEffects"
diagnostic_helper="${app_path}/Contents/Helpers/keyboard-light-cli"
info_plist="${app_path}/Contents/Info.plist"

if [[ ! -x "$app_executable" || ! -x "$diagnostic_helper" || ! -f "$info_plist" ]]; then
  print -u2 "INVALID: The app bundle is incomplete at $app_path"
  exit 1
fi

/usr/bin/codesign --verify --deep --strict --verbose=2 "$app_path"

bundle_identifier="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$info_plist")"
if [[ "$bundle_identifier" != "local.codex.keyboard-light-effects" ]]; then
  print -u2 "INVALID: Unexpected bundle identifier: $bundle_identifier"
  exit 1
fi

brightness="$($diagnostic_helper get)"
if ! /usr/bin/awk -v value="$brightness" 'BEGIN { exit !(value >= 0.0 && value <= 1.0) }'; then
  print -u2 "HARDWARE CHECK FAILED: brightness=$brightness"
  print -u2 "Retry outside the Codex sandbox if hardware access was restricted."
  exit 1
fi

print "VERIFIED: $app_path"
print "KEYBOARD BRIGHTNESS: $brightness"
