#!/bin/zsh
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  print -u2 "UNSUPPORTED: This skill requires macOS."
  exit 1
fi

if [[ "$(uname -m)" != "arm64" ]]; then
  print -u2 "UNSUPPORTED: This build targets Apple Silicon MacBooks."
  exit 1
fi

if [[ ! -x /usr/bin/clang ]]; then
  print -u2 "MISSING: Apple clang is unavailable. Install Xcode Command Line Tools first."
  exit 1
fi

if [[ ! -d /System/Library/PrivateFrameworks/CoreBrightness.framework ]]; then
  print -u2 "UNSUPPORTED: CoreBrightness.framework is unavailable."
  exit 1
fi

hid_devices="$(/usr/bin/hidutil list 2>/dev/null || true)"
if [[ "$hid_devices" != *"Keyboard Backlight"* ]]; then
  print -u2 "UNSUPPORTED: No built-in Keyboard Backlight HID device was found."
  exit 1
fi

model_identifier="$(/usr/sbin/system_profiler SPHardwareDataType 2>/dev/null | /usr/bin/awk -F': ' '/Model Identifier/{print $2; exit}')"
print "COMPATIBLE: ${model_identifier:-Apple Silicon MacBook}"
