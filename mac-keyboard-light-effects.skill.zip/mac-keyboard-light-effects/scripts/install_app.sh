#!/bin/zsh
set -euo pipefail

script_dir="${0:A:h}"
skill_dir="${script_dir:h}"
install_root="${1:-${HOME}/Applications}"
app_path="${install_root}/鍵盤呼吸燈.app"
temporary_root="$(mktemp -d "${TMPDIR:-/tmp}/mac-keyboard-light-effects.XXXXXX")"
temporary_app="${temporary_root}/鍵盤呼吸燈.app"

cleanup() {
  rm -rf "$temporary_root"
}
trap cleanup EXIT

"${script_dir}/check_compatibility.sh"

mkdir -p "${temporary_app}/Contents/MacOS"
mkdir -p "${temporary_app}/Contents/Helpers"
mkdir -p "${temporary_app}/Contents/Resources"

/usr/bin/clang -fobjc-arc -Wall -Wextra \
  -framework Cocoa \
  -framework CoreFoundation \
  -framework ApplicationServices \
  -framework AVFoundation \
  -o "${temporary_app}/Contents/MacOS/KeyboardBreathing" \
  "${skill_dir}/assets/KeyboardLightApp.m"

/usr/bin/clang -fobjc-arc -Wall -Wextra \
  -framework Cocoa \
  -framework CoreFoundation \
  -o "${temporary_app}/Contents/Helpers/keyboard-light-cli" \
  "${skill_dir}/assets/KeyboardLightCLI.m"

/bin/cp "${skill_dir}/assets/Info.plist" "${temporary_app}/Contents/Info.plist"
/bin/cp "${skill_dir}/references/THIRD_PARTY_NOTICES.txt" \
  "${temporary_app}/Contents/Resources/THIRD_PARTY_NOTICES.txt"

/usr/bin/xattr -cr "$temporary_app" 2>/dev/null || true
/usr/bin/codesign --force --deep --sign - "$temporary_app"
/usr/bin/codesign --verify --deep --strict "$temporary_app"

/bin/mkdir -p "$install_root"
if [[ -d "$app_path" ]]; then
  /bin/mkdir -p "${app_path}/Contents/MacOS"
  /bin/mkdir -p "${app_path}/Contents/Helpers"
  /bin/mkdir -p "${app_path}/Contents/Resources"
  /bin/rm -f "${app_path}/Contents/MacOS/KeyboardLightEffects"
  /bin/cp "${temporary_app}/Contents/MacOS/KeyboardBreathing" \
    "${app_path}/Contents/MacOS/KeyboardBreathing"
  /bin/cp "${temporary_app}/Contents/Helpers/keyboard-light-cli" \
    "${app_path}/Contents/Helpers/keyboard-light-cli"
  /bin/cp "${temporary_app}/Contents/Info.plist" "${app_path}/Contents/Info.plist"
  /bin/cp "${temporary_app}/Contents/Resources/THIRD_PARTY_NOTICES.txt" \
    "${app_path}/Contents/Resources/THIRD_PARTY_NOTICES.txt"
else
  /usr/bin/ditto --norsrc --noextattr "$temporary_app" "$app_path"
fi

/usr/bin/xattr -cr "$app_path" 2>/dev/null || true
/usr/bin/codesign --force --deep --sign - "$app_path"
/usr/bin/codesign --verify --deep --strict --verbose=2 "$app_path"

print "INSTALLED: $app_path"
